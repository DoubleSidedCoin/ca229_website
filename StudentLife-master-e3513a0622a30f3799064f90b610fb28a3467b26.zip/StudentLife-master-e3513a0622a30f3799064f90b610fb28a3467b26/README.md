Page 1 = Introduce app and how you can use it.

Page 2 = Profile page to describe student. Student can edit, add and delete information about themselves.

Page 3 = Timetable page for student.

Page 4 = List of buildings and they're names , that the student will have to go to.

Page 5 = All contact details of the students lecturers.
